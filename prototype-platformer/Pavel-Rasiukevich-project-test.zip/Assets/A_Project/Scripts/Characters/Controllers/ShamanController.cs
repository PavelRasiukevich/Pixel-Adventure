namespace PixelAdventure
{
    public class ShamanController : BaseController
    {
        
    }
}
