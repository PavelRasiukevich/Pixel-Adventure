namespace PixelAdventure
{
    public class PinkyController : BaseController
    {
        
    }
}
