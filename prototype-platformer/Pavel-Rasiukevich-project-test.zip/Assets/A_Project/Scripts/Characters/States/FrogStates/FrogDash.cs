namespace PixelAdventure
{
    public class FrogDash : BaseState
    {
        public override StatesEnum State => StatesEnum.Dash;
    }
}
