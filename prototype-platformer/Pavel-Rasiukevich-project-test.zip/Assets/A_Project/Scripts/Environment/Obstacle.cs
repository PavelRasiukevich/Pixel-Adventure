using UnityEngine;

namespace PixelAdventure
{
    public class Obstacle : MonoBehaviour, IDamaging
    {
        
    }
}
